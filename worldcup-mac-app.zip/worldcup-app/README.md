# World Cup — Mac App (DMG installer)

Everything is pre-built except the final .dmg, which macOS has to
assemble itself (Apple's hdiutil only exists on Macs).

## Build the installer (one time, ~2 minutes)
On your Mac, in this folder:

    npm install
    npm run dist

The installer appears at:  dist/World Cup-1.0.0-arm64.dmg

Double-click it and you get the classic installer window — ball icon,
gold arrow, drag to Applications — then World Cup lives in your dock.

Intel Mac instead? Change "arm64" to "x64" in package.json (mac.target),
or use ["arm64","x64"] to build both.

## Test without building
    npm start

## Heads up: Gatekeeper
The app is unsigned (code signing requires a $99/yr Apple Developer ID),
so the FIRST launch on any Mac needs: right-click the app → Open → Open.
On macOS 15+ it may instead be: System Settings → Privacy & Security →
scroll down → "Open Anyway". After that it opens normally forever.

## Updating the scoreboard
The web app lives in app/ — same files as the GitHub Pages version.
Edit, then re-run `npm run dist` to cut a new DMG.

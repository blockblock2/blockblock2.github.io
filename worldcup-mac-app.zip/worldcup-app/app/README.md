# World Cup Live Scoreboard (PWA)

Live scores + play-by-play for every FIFA World Cup, powered by ESPN's
public scoreboard feed. No API key, no backend.

## Deploy
Copy this whole folder into your GitHub Pages repo as `worldcup/`
so it's served at https://<you>.github.io/worldcup/

The service worker only controls the /worldcup/ path — it won't touch
the rest of your site.

## Install as an app
- iPhone/iPad: open the URL in Safari → Share → Add to Home Screen
- Mac Safari: File → Add to Dock
- Chrome/Edge (desktop or Android): install icon in the address bar

## Customize
- Tournaments: edit the TOURNAMENTS array at the top of index.html
- Polling speed: REFRESH_LIVE_MS (15s) and REFRESH_IDLE_MS (3 min)
- After changing files, bump CACHE in sw.js (v1 → v2) so installed
  apps pick up the update.
